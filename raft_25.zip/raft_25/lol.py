file = open("rndm.txt", "a+")

for i in range(10):
    file.write(str(i) + "\n")
